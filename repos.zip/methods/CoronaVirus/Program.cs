﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoronaVirus
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Podaj swoją teperaturę w stopniach Fahrenheita: ");
            double temperature = double.Parse(Console.ReadLine());

            temperature = FahrenheitToCelsius(temperature);
            Console.WriteLine($"Temperatura w stopniach Celcjusza wynosi {temperature}");

            if (ishehealthy(temperature))
            {
                Console.WriteLine("Jesteś zdrowy");
            }
            else
            {
                Console.WriteLine("Poddaj się kwarantannie!");
            }
            Console.ReadKey();
        }
        static double FahrenheitToCelsius(double degrees)
        {
            return (degrees - 32) * 5 / 9;
        }
        static bool ishehealthy (double CelsiusDegrees)
        {
            if (CelsiusDegrees >= 37.5)
            {
                return false;
            
            }
            else
            {
                return true;
            }
        }
    }
}
