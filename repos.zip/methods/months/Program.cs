﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace months
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Podaj numer pierwszego miesiąca: ");
            int firstMonth = int.Parse(Console.ReadLine());

           

            Console.WriteLine("Podaj numer drugiego miesiąca: ");
            int secondMonth = int.Parse(Console.ReadLine());

            SayMonth(secondMonth, firstMonth);

            
            Console.ReadKey();
        }

        static void SayMonth(int secondMonth , int firstMonth)
        {
            string[] monthNames = new string[]
            {
                "Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec", "Lipiec", "Wrzesień", "Październik", "Listopad", "Grudzień"
            };
            int różnica = secondMonth - firstMonth;

            if (różnica < 0)
            {
                różnica = różnica * (-1);
            }
            Console.Write("Różnica między miesiącami " + monthNames[firstMonth] + " a " + monthNames[secondMonth] + " = " + różnica);
            
            

        }
    }
}
