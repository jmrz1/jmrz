﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simpleclass
{
    class Program
    {
        static void Main(string[] args)
        {
            Car MyCar = new Car();
            MyCar.Color = "srebrne";
            MyCar.Make = "Subaru";
            MyCar.Model = "Legacy";
            MyCar.Year = 2007;

            string res = $"Mam {MyCar.Color} {MyCar.Make} {MyCar.Model} z {MyCar.Year} roku, które jest warte {MyCar.DetermineValue()} zł.";
            Console.WriteLine(res);
            Console.ReadKey();

        }
    }
   
}
